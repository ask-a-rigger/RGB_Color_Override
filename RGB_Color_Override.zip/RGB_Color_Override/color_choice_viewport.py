import maya.cmds as cmds



def rbsColorChangeViewport (rgbR,rgbG,rgbB, ViewportColor=True):
    x = cmds.ls(selection=True)
    for i in x:
        #changes the color in the viewport
        cmds.setAttr ( i + ".overrideEnabled", ViewportColor)   
        cmds.setAttr ( i + ".overrideRGBColors" , True)
        cmds.setAttr ( i + ".overrideColorRGB", rgbR,rgbG,rgbB)
        
rbsColorChangeViewport(1,0,0)