import maya.cmds as cmds



def rbsColorChangeOutliner (rgbR,rgbG,rgbB, OutlinerColor=True):
    x = cmds.ls(selection=True)
    for i in x:
        #changes the color in the outliner
        cmds.setAttr ( i + ".useOutlinerColor" , OutlinerColor)
        cmds.setAttr ( i + ".outlinerColor", rgbR,rgbG,rgbB)
        
rbsColorChangeOutliner(.500,0,0)