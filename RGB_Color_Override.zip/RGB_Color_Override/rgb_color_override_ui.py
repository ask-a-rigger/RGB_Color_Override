from functools import partial

from PySide2 import QtCore
from PySide2 import QtGui
from PySide2 import QtWidgets
from shiboken2 import wrapInstance

import maya.cmds as cmds
import maya.OpenMayaUI as omui

import RGB_Color_Override.color_choice_viewport
import RGB_Color_Override.color_choice_outliner

def maya_main_window():
    """
    Return the Maya main window widget as a Python object
    """
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(long(main_window_ptr), QtWidgets.QWidget)


class CustomColorButton(QtWidgets.QWidget):

    color_changed = QtCore.Signal(QtGui.QColor)


    def __init__(self, color=QtCore.Qt.white, parent=None):
        super(CustomColorButton, self).__init__(parent)

        self.setObjectName("CustomColorButton")

        self.create_control()

        self.set_size(299, 30)
        self.set_color(color)

    def create_control(self):
        """ 1) Create the colorSliderGrp """
        window = cmds.window()
        color_slider_name = cmds.colorSliderGrp()

        """ 2) Find the colorSliderGrp widget """
        self._color_slider_obj = omui.MQtUtil.findControl(color_slider_name)
        if self._color_slider_obj:
            self._color_slider_widget = wrapInstance(long(self._color_slider_obj), QtWidgets.QWidget)

            """ 3) Reparent the colorSliderGrp widget to this widget """
            main_layout = QtWidgets.QVBoxLayout(self)
            main_layout.setObjectName("main_layout")
            main_layout.setContentsMargins(1,1,1,1)
            main_layout.addWidget(self._color_slider_widget)

            """ 4) Identify/store the colorSliderGrps child widgets (and hide if necessary)  """
            # children = self._color_slider_widget.children()
            # for child in children:
            #     print(child)
            #     print(child.objectName())
            # print("---")

            self._slider_widget = self._color_slider_widget.findChild(QtWidgets.QWidget, "slider")
            if self._slider_widget:
                self._slider_widget.hide()

            self._color_widget = self._color_slider_widget.findChild(QtWidgets.QWidget, "port")

            cmds.colorSliderGrp(self.get_full_name(), e=True, changeCommand=partial(self.on_color_changed))


        cmds.deleteUI(window, window=True)

    def get_full_name(self):
        return omui.MQtUtil.fullName(long(self._color_slider_obj))

    def set_size(self, width, height):
        self._color_slider_widget.setFixedWidth(100)
        self._color_widget.setFixedHeight(50)

    def set_color(self, color):
        color = QtGui.QColor(color)

        cmds.colorSliderGrp(self.get_full_name(), e=True, rgbValue=(color.redF(), color.greenF(), color.blueF()))
        self.on_color_changed()

    def get_color(self):
        # color = cmds.colorSliderGrp(self._color_slider_widget.objectName(), q=True, rgbValue=True)
        color = cmds.colorSliderGrp(self.get_full_name(), q=True, rgbValue=True)

        color = QtGui.QColor(color[0] *255, color[1] *255, color[2] *255)
        return color

    def on_color_changed(self, *args):
        self.color_changed.emit(self.get_color())


class CustomColorOverride(QtWidgets.QDialog):

    WINDOW_TITLE = "RGB Color Override"

    def __init__(self, parent=maya_main_window()):
        super(CustomColorOverride, self).__init__(parent)

        self.setObjectName("CustomColorOverride")

        self.setWindowTitle(self.WINDOW_TITLE)
        if cmds.about(ntOS=True):
            self.setWindowFlags(self.windowFlags() ^ QtCore.Qt.WindowContextHelpButtonHint)
        elif cmds.about(macOS=True):
            self.setWindowFlags(QtCore.Qt.Tool)

        self.setMinimumSize(500, 250)
        self.setMaximumSize(500, 250)

        self.outliner_color = QtCore.Qt.red
        self.viewport_color = QtCore.Qt.green
        self.both_color = QtCore.Qt.blue

        self.create_widgets()
        self.create_layout()
        self.create_connections()

    def create_widgets(self):
        self.outliner_color_btn = CustomColorButton(self.outliner_color)
        self.viewport_color_btn = CustomColorButton(self.viewport_color)
        self.both_color_btn = CustomColorButton(self.both_color)

        self.print_outliner_color_btn = QtWidgets.QPushButton("Apply Outliner Color")
        self.print_viewport_color_btn = QtWidgets.QPushButton("Apply Viewport Color")
        self.print_both_color_btn = QtWidgets.QPushButton("Apply Both Color")

        self.close_btn = QtWidgets.QPushButton("Close")

    def create_layout(self):
        color_layout = QtWidgets.QFormLayout()
        color_layout.addRow("Outliner:", self.outliner_color_btn)
        color_layout.addRow("Viewport:", self.viewport_color_btn)
        color_layout.addRow("Both:", self.both_color_btn)
        

        color_grp = QtWidgets.QGroupBox("Color Options")
        color_grp.setObjectName("colorGrp")
        color_grp.setLayout(color_layout)

        button_layout = QtWidgets.QVBoxLayout()
        button_layout.setContentsMargins(2,2,2,2)
        button_layout.setSpacing(25)
        button_layout.addStretch()
        button_layout.addWidget(self.print_outliner_color_btn)
        button_layout.setSpacing(25)
        button_layout.addWidget(self.print_viewport_color_btn)
        button_layout.addWidget(self.print_both_color_btn)
        button_layout.addStretch()
        button_layout.addWidget(self.close_btn)

        main_layout = QtWidgets.QHBoxLayout(self)
        main_layout.setContentsMargins(10,10,10,10)
        main_layout.addWidget(color_grp)
        main_layout.addLayout(button_layout)

    def create_connections(self):
        self.outliner_color_btn.color_changed.connect(self.on_outliner_color_changed)
        self.viewport_color_btn.color_changed.connect(self.on_viewport_color_changed)
        self.both_color_btn.color_changed.connect(self.on_both_color_changed)

        self.print_outliner_color_btn.clicked.connect(self.print_outliner_color)
        self.print_viewport_color_btn.clicked.connect(self.print_viewport_color)
        self.print_both_color_btn.clicked.connect(self.print_both_color)
        

        self.close_btn.clicked.connect(self.close)

    def on_outliner_color_changed(self, new_color):
        print("New Outliner color: ({0:.3f}, {1:.3f}, {2:.3f})".format(new_color.red(), new_color.green(), new_color.blue()))

    def on_viewport_color_changed(self, new_color):
        print("New Viewport color: ({0:.3f}, {1:.3f}, {2:.3f})".format(new_color.red(), new_color.green(), new_color.blue()))

    def on_both_color_changed(self, new_color):
        print("New Both color: ({0:.3f}, {1:.3f}, {2:.3f})".format(new_color.red(), new_color.green(), new_color.blue()))
        
    def print_outliner_color(self):
        color = self.outliner_color_btn.get_color()
        print("Outliner color: ({0:.3f}, {1:.3f}, {2:.3f})".format(color.red(), color.green(), color.blue()))
        RGB_Color_Override.color_choice_outliner.rbsColorChangeOutliner((color.red()/255.000), (color.green()/255.000), (color.blue()/255.000), OutlinerColor=True)

    def print_viewport_color(self):
        color = self.viewport_color_btn.get_color()
        print("Viewport color: ({0:.3f}, {1:.3f}, {2:.3f})".format(color.red(), color.green(), color.blue()))
        RGB_Color_Override.color_choice_viewport.rbsColorChangeViewport((color.red()/255.000), (color.green()/255.000), (color.blue()/255.000), ViewportColor=True)
     
    def print_both_color(self):
        color = self.both_color_btn.get_color()
        print("Both color: ({0:.3f}, {1:.3f}, {2:.3f})".format(color.red(), color.green(), color.blue()))
        RGB_Color_Override.color_choice_viewport.rbsColorChangeViewport((color.red()/255.000), (color.green()/255.000), (color.blue()/255.000), ViewportColor=True)
        RGB_Color_Override.color_choice_outliner.rbsColorChangeOutliner((color.red()/255.000), (color.green()/255.000), (color.blue()/255.000), OutlinerColor=True)
        
if __name__ == "__main__":

    try:
        embedded_custom_color_override.close() # pylint: disable=E0601
        embedded_custom_color_override.deleteLater()
    except:
        pass

    embedded_custom_color_override = CustomColorOverride()
    embedded_custom_color_override.show()

def color_change_main():
    embedded_custom_color_override = CustomColorOverride()
    embedded_custom_color_override.show()
    
    